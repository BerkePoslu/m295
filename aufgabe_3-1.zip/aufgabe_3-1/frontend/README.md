frontend mostly created by chatgpt
async await and most of the other technical stuff by me